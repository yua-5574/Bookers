Rails.application.routes.draw do
  root :to => 'books#new'
  # post 'books' => 'books#create'
  # get 'books/:id' => 'books#show', as: 'book'
  # patch 'books/:id' => 'books#update', as: 'update_book'
  # put 'books/:id' => 'books#update'
  # get 'books/index'
  # get 'books/show'
  # get 'books/new'
  # get 'books/edit'
  # get 'books/:id/edit' => 'books#edit', as: 'edit_book'
  # get 'books' => 'books#index'
  # # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

  # delete 'books/:id' => 'books#destroy', as: 'destroy_book'
  resources :books
end
